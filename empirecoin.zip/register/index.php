<?php

if(isset($_POST['submit'])){
	require("register_process.php");
}

require_once("view.php");

?>