<!DOCTYPE html>
<html>
<head>
	<title>Empirecoin</title>
	<meta charset="utf-8">
</head>
<body>
	<a href="login">Login</a>
	<a href="register">Register</a>
</body>
</html>