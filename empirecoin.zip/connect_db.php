<?php 
$connect = mysql_connect("localhost","root","123") or die ("Couldn't connect!");
mysql_select_db("empirecoin") or die ("Couldn't find Database");
?>
