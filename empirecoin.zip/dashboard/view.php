<!DOCTYPE html>
<html>
<head>
	<title>Dashboard | Empirecoin</title>
	<meta charset="utf-8">
</head>
<body>
	<h1>Dashboard</h1>


</body>
</html>